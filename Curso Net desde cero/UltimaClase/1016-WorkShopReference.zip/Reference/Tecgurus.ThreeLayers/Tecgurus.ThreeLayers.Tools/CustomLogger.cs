﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tecgurus.ThreeLayers.Tools
{
    public class CustomLogger
    {
        public static Logger logger = LogManager.GetCurrentClassLogger();

        public static Logger loggerDataBase = LogManager.GetLogger("databaseLogger");

    }
}
